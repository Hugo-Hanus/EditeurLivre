package org.helmo.gbeditor.domains;


import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;

/**
 * Class of Testing the ISBN and the security Number
 */
public class EditingTest {


    public static final String ISBN_ONLY_ZERO = "0-000000-00-0";
    public static final String RESUME = "Resume";
    public static final String TITLE = "Resume";

    /**@Test Validation des champs de connexion
     *
     * @PremierCas 2 champs vide
     * @DeuxiemeCas 1 champs vide (Name)
     * @TroisiemeCas 1champs vide (firstname)
     * @QuatriemeCas 2 champs contenant un espace chacun
     * @CinquiemeCas Cas Basique
     * */
    public @Test
    void testValidationEmptyFieldConnection() {
        Editing edit = new Editing();
        assertFalse(edit.checkEntryConnection("",""));
        assertFalse(edit.checkEntryConnection("","Firstame"));
        assertFalse(edit.checkEntryConnection("Name",""));
        assertFalse(edit.checkEntryConnection(" "," "));
        assertTrue(edit.checkEntryConnection("Name","Firstame"));
    }
    /**@Test Validation des champs du crétion de Livre
     *
     * @PremierCas 3 champs vide
     * @DeuxiemeCas 3 champs contentant des espace
     * @TroisiemeCas 2 champs vide (ISBN + resume)
     * @QuatriemeCas 2 champs vide (title + resume)
     * @CinquiemeCas 2 champs vide (title + ISBN)
     * @SixiemeCas Cas Basique
     * */
    public @Test
    void testValidationEmptyFieldCreationBook() {
        Editing edit = new Editing();
        assertFalse(edit.checkEntryCreateBook("","",""));
        assertFalse(edit.checkEntryCreateBook(" "," "," "));
        assertFalse(edit.checkEntryCreateBook(RESUME,"",""));
        assertFalse(edit.checkEntryCreateBook("", ISBN_ONLY_ZERO,""));
        assertFalse(edit.checkEntryCreateBook("","",RESUME));
        assertTrue(edit.checkEntryCreateBook(TITLE,ISBN_ONLY_ZERO,RESUME));
    }
    /**@Test Validation des longueurs des champs du creation de livre
     *
     * @PremierCas Titre superieur a 150 caractere (length<150)
     * @DeuxiemeCas Resume superieur a 500 caractere (length<500)
     * @TroisiemeCas Titre superieur a 150 caractere (length<150) && Resume superieur a 500 caractere (length<500)
     * @QuatriemeCas Cas Basique
     * */
    public @Test
    void testValidationLengthFieldCreationBook() {
        Editing edit = new Editing();
        String centCinquanteCharactere="Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Aenean commodo ligula eget dolor. Aenean massa. Cum sociis natoque penatibus et magnis dis p";
        String CinqCentCharactere="Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Aenean commodo ligula eget dolor. Aenean massa. Cum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Donec quam felis, ultricies nec, pellentesque eu, pretium quis, sem. Nulla consequat massa quis enim. Donec pede justo, fringilla vel, aliquet nec, vulputate eget, arcu. In enim justo, rhoncus ut, imperdiet a, venenatis vitae, justo. Nullam dictum felis eu pede mollis pretium. Integer tincidunt. Cras dapibu";
        assertFalse(edit.checkEntryCreateBook(centCinquanteCharactere,ISBN_ONLY_ZERO, RESUME));
        assertFalse(edit.checkEntryCreateBook(TITLE,ISBN_ONLY_ZERO,CinqCentCharactere));
        assertFalse(edit.checkEntryCreateBook(centCinquanteCharactere,ISBN_ONLY_ZERO,CinqCentCharactere));
        assertTrue(edit.checkEntryCreateBook(TITLE,ISBN_ONLY_ZERO,RESUME));
    }



    /***
     * @Test Validation du Code ISBN avec cas speciaux
     *
     * @PremierCas Cas basique
     * @DeuxiemeCas Mon identifiant et premier livre
     * @TroisiemeCas Code de Controle est egale a 10 donc remplace par X
     * @QuatriemeCas Code de Controle est egale a 11 donc remplace par 0
     * @CinquiemeCas Exemple du cours
     */
    public @Test
    void testValidationNumberCorrect() {
        Editing edit = new Editing();
        assertTrue(edit.verifyISBN(ISBN_ONLY_ZERO));
        assertTrue(edit.verifyISBN("2-190533-01-5"));
        assertTrue(edit.verifyISBN("2-190533-21-X"));
        assertTrue(edit.verifyISBN("1-091300-10-0"));
        assertTrue(edit.verifyISBN("2-070039-01-3"));
    }

    /***
     * @Test Validation du Code ISBN sur des codes faux
     */
    public @Test
    void testValidationNumberNotCorrect() {
        Editing edit = new Editing();
        assertFalse(edit.verifyISBN("0-000000-10-0"));
        assertFalse(edit.verifyISBN("2-000000-01-5"));
        assertFalse(edit.verifyISBN("2-190533-23-X"));
        assertFalse(edit.verifyISBN("2-070010-01-3"));
        assertFalse(edit.verifyISBN("2-070010-01-32"));
    }

}
