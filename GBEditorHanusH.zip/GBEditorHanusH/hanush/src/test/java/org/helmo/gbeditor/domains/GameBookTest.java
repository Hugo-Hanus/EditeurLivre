package org.helmo.gbeditor.domains;

import org.junit.jupiter.api.Test;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static org.junit.jupiter.api.Assertions.*;
/**
 * Test for class GameBook
 */
public class GameBookTest {

    public static final String MY_GAME_BOOK = "My GameBook";
    public static final String ISBN = "123456";
    public static final String RESUME = "A fun adventure";
    public static final String TITLE = "New title";
    public static final String ISBNT = "654321";
    public static final String NRESUME = "A new adventure";
    public static final String TEXT_PAGE = "Some text";

    /**
     *@Test Test GameBookConstructor method
     */
    @Test
    public void testGameBookConstructor() {
        // Test with valid input
        Map<Integer, Page> pages = new HashMap<>();
        List<Choice> list=new ArrayList<>();
        pages.put(1, new Page(TEXT_PAGE,1,list));
        GameBook gameBook = new GameBook(MY_GAME_BOOK, ISBN, RESUME, true, pages);
        assertEquals(MY_GAME_BOOK, gameBook.getTitle());
       assertEquals(ISBN, gameBook.getIsbn());
        assertEquals(RESUME, gameBook.getResume());
        assertTrue(gameBook.isPublish());
        assertEquals(pages, gameBook.getMapPage());
    }
    /**
     *@Test Test SetTitle method
     */
    @Test
    public void testSetTitle() {
        GameBook gameBook = new GameBook(MY_GAME_BOOK, ISBN, RESUME, true, new HashMap<>());
        gameBook.setTitle(TITLE);
        assertEquals(TITLE, gameBook.getTitle());
    }

    /**
     *@Test Test SetIsbn method
     */
    @Test
    public void testSetIsbn() {
        GameBook gameBook = new GameBook(MY_GAME_BOOK, ISBN, RESUME, true, new HashMap<>());
        gameBook.setIsbn(ISBNT);
        assertEquals(ISBNT, gameBook.getIsbn());
    }

    /**
     *@Test Test SetResume method
     */
    @Test
    public void testSetResume() {
        GameBook gameBook = new GameBook(MY_GAME_BOOK, ISBN, RESUME, true, new HashMap<>());
        gameBook.setResume(NRESUME);
        assertEquals(NRESUME, gameBook.getResume());
    }

    /**
     *@Test Test SetPublish method
     */
    @Test
    public void testSetPublish() {
        GameBook gameBook = new GameBook(MY_GAME_BOOK, ISBN, RESUME, true, new HashMap<>());
        gameBook.setPublish(false);
       assertFalse(gameBook.isPublish());
        gameBook.setPublish(true);
        assertTrue(gameBook.isPublish());
    }
    /**
     *@Test Test AddPage method
     */
    @Test
    public void testAddPage() {
        Map<Integer, Page> pages = new HashMap<>();
        GameBook gameBook = new GameBook(MY_GAME_BOOK, ISBN, RESUME, true, pages);
        List<Choice> list=new ArrayList<>();
        Page page=new Page(TEXT_PAGE,1,list);
        assertTrue(gameBook.addPage(page));
        assertFalse(gameBook.addPage(page));
    }

    /**
     *@Test Test FormatGameBook method
     */
    @Test
    public void testFormatGameBookWithPublish() {
        Map<Integer, Page> pages = new HashMap<>();
        GameBook gameBook = new GameBook(MY_GAME_BOOK, ISBN, RESUME, true, pages);
        assertEquals("Publié 123456 || My GameBook", gameBook.formatGameBook(true));
    }

    /**
     *@Test Test formatGameBook method
     */
    @Test
    public void testFormatGameBookWithoutPublish() {
        Map<Integer, Page> pages = new HashMap<>();
        GameBook gameBook = new GameBook(MY_GAME_BOOK, ISBN, RESUME, false, pages);
        assertEquals("123456 || My GameBook", gameBook.formatGameBook(false));
    }

    /**
     *@Test Test editGameBook method
     */
    @Test
    public void testEditGameBook() {
        Map<Integer, Page> pages = new HashMap<>();
        GameBook gameBook = new GameBook(MY_GAME_BOOK, ISBN, RESUME, true, pages);
        gameBook.editGameBook(TITLE, ISBNT, NRESUME);
        assertEquals(TITLE, gameBook.getTitle());
        assertEquals(ISBNT, gameBook.getIsbn());
        assertEquals(NRESUME, gameBook.getResume());
    }

    /**
     *@Test Test isEmpty method
     */
    @Test
    public void testIsEmptyWithEmptyMap() {
        Map<Integer, Page> pages = new HashMap<>();
        GameBook gameBook = new GameBook(MY_GAME_BOOK, ISBN, RESUME, true, pages);
        assertTrue(gameBook.isEmpty());
    }

    /**
     *@Test Test isEmpty method
     */
    @Test
    public void testIsEmptyWithNonEmptyMap() {
        Map<Integer, Page> pages = new HashMap<>();
        List<Choice> list=new ArrayList<>();
        Page page=new Page(TEXT_PAGE,1,list);
        pages.put(1,page);
        GameBook gameBook = new GameBook(MY_GAME_BOOK, ISBN, RESUME, true, pages);

        assertFalse(gameBook.isEmpty());
    }
    /**
     *@Test Test clearPage method
     */
    @Test
    public void testClearPage() {
        Map<Integer, Page> pages = new HashMap<>();
        List<Choice> list=new ArrayList<>();
        Page page=new Page(TEXT_PAGE,1,list);
        pages.put(1, page);
        GameBook gameBook = new GameBook(MY_GAME_BOOK, ISBN, RESUME, true, pages);
        gameBook.clearPage();
        assertTrue(gameBook.isEmpty());
    }



}
