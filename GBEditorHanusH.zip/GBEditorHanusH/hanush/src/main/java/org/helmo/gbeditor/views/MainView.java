package org.helmo.gbeditor.views;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.scene.*;
import javafx.scene.control.*;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.VBox;

import org.helmo.gbeditor.presenters.Presenter;
import org.helmo.gbeditor.presenters.ViewInterface;
import org.helmo.gbeditor.infrastructure.storage.storage.exception.UnableToInsertInDb;
import org.helmo.gbeditor.infrastructure.storage.storage.exception.UnableToSetupException;

import java.util.Optional;

/***
 * Class MainView of the Program
 */
public class MainView implements ViewInterface {
    private Presenter presenter;
    private final Label messageH = new Label("Message : ");
    private final Label message = new Label("");
    private final Label user = new Label("Utilisateur : ");
    private final Label userName = new Label("");
    private final Label publishLabel = new Label("Publier le livre");
   private  ObservableList<String> oList= FXCollections.observableArrayList();
   private  ObservableList<String> oPageList = FXCollections.observableArrayList();

    private final ListView<String> vueEnList=new ListView<>();{
        vueEnList.setItems(oList);
        vueEnList.setOnMouseClicked(new EventHandler<MouseEvent>() {
            @Override
            public void handle(MouseEvent event) {
                if(event.getClickCount()==2){
                    String element = vueEnList.getSelectionModel().getSelectedItem();
                    if(element ==null){
                    presenter.setMessage("Aucun livre sélectioné");
                    }else if(element.startsWith("Publié")){
                        presenter.setMessage("Livre déjà publié");
                    }else{
                        setCurrentGamebookRead(element.substring(0,13));
                        oPageList=(ObservableList<String>) presenter.updateOPageList(element.substring(0,13),oPageList);
                        onlyConnection(3);

                    }
                }
            }
        });
    }
    private final ListView<String> pageEnList=new ListView<>();{
            pageEnList.setItems(oPageList);
        pageEnList.setOnMouseClicked(new EventHandler<MouseEvent>() {
            @Override
            public void handle(MouseEvent event) {
                if(event.getClickCount()==2){
                    String element = pageEnList.getSelectionModel().getSelectedItem();

                }
            }
        });
    }
    private final BorderPane authenticatorPane = new ViewAuthenticationBP();
    private final BorderPane createBP= new ViewCreateBP();
    private final BorderPane createBookBP= new ViewCreateBookBP("Créer le livre");
    private final BorderPane editInfoBook = new ViewEditBookBP("Modifier les information du Livre","","","","");
    private final BorderPane addingPageChoice = new ViewAddingPageChoiceBP("-1");

    private static  StackPane centerStack = new StackPane();{
        centerStack.getChildren().addAll(authenticatorPane,createBP,createBookBP,addingPageChoice,editInfoBook);
    }
    private static  VBox messageBox = new VBox();{
        messageBox.getChildren().add(messageH);
        messageBox.getChildren().add(message);
    }
    private static  HBox userBox = new HBox();{
        userBox.getChildren().add(user);
        userBox.getChildren().add(userName);
    }
    private static  BorderPane mainPane = new BorderPane();{
        mainPane.setTop(userBox);
        mainPane.setCenter(centerStack);
        mainPane.setBottom(messageBox);
    }





    /***
     *  Internal Class with field to create a GameBook
     */
    public class ViewCreateBookBP extends BorderPane{
        /***
         * Constructor of BorderPane to create a GameBook
         */
    public ViewCreateBookBP(String actionButton){
        Label title = new Label("Titre : ");
        TextField titleEntry= new TextField("");
        Label isbn = new Label("ISBN : ");
        TextField isbnEntry= new TextField("");
        Label resume = new Label("Resume : ");
        TextArea resumeEntry= new TextArea("");
        Button returnButton = new Button("Retour");
        {
            returnButton.getStyleClass().add("delete");
            returnButton.setOnAction(event -> {
                clearField(titleEntry,isbnEntry,resumeEntry);
                oList = (ObservableList<String>) presenter.updateOList(oList);
                onlyConnection(1);
            });
        }
        Button createBookButton = new Button(actionButton);{
            createBookButton.getStyleClass().add("add");
            createBookButton.setOnAction(event -> {
                        try{
                if(presenter.checkISBN(isbnEntry.getText())){
                    if(presenter.newBook(titleEntry.getText(),isbnEntry.getText(),resumeEntry.getText())){
                      oList =(ObservableList<String>) presenter.updateOList(oList);
                    }
                    clearField(titleEntry,isbnEntry,resumeEntry);
                }else{
                    presenter.setMessage(" ISBN: Mauvais format 9-999999-99-9 ");
                }
                }catch(UnableToInsertInDb | UnableToSetupException e){
                     presenter.setMessage("Impossbile de créer le Livre dans la base de donnée");
                }
            });
        }
        VBox creationBook = new VBox();{
            creationBook.getChildren().add(title);
            creationBook.getChildren().add(titleEntry);
            creationBook.getChildren().add(isbn);
            creationBook.getChildren().add(isbnEntry);
            creationBook.getChildren().add(resume);
            creationBook.getChildren().add(resumeEntry);
            creationBook.getChildren().add(createBookButton);
            creationBook.getChildren().add(returnButton);
        }
        setCenter(creationBook);
    }
    }
    /***
     *  Internal Class with field to edit a GameBook
     */
    public class ViewEditBookBP extends BorderPane{
        /***
         * Constructor of BorderPane to edit  a GameBook
         */
        public ViewEditBookBP(String naming,String titleGB,String isbnGB,String ResumeGB,String choose){
            Label title = new Label("Titre : ");
            TextField titleEntry= new TextField(titleGB);
            Label isbn = new Label("ISBN : ");
            TextField isbnEntry= new TextField(isbnGB);
            Label resume = new Label("Resume : ");
            TextArea resumeEntry= new TextArea(ResumeGB);
            Button returnButton = new Button("Retour");
            {
                returnButton.getStyleClass().add("delete");
                returnButton.setOnAction(event -> {
                    clearField(titleEntry,isbnEntry,resumeEntry);
                    oList =(ObservableList<String>) presenter.updateOList(oList);
                    onlyConnection(1);
                    presenter.setMessage("Edition annulé");
                });
            }
            Button createBookButton = new Button(naming);{
                createBookButton.getStyleClass().add("add");
                createBookButton.setOnAction(event -> {
                    if(presenter.checkISBN(isbnEntry.getText())){
                        if(presenter.updateGameBook(choose,titleEntry.getText(),isbnEntry.getText(),resumeEntry.getText())){
                            oList =(ObservableList<String>) presenter.updateOList(oList);
                            onlyConnection(1);
                            clearField(titleEntry,isbnEntry,resumeEntry);
                        }else{
                            presenter.setMessage("Certains champ sont vides ou dépasse la taille demandée");
                        }
                    }else{
                        presenter.setMessage(" ISBN: Mauvais format 9-999999-99-9 ");
                    }
                });
            }
            VBox editionBook = new VBox();{
                editionBook.getChildren().add(title);
                editionBook.getChildren().add(titleEntry);
                editionBook.getChildren().add(isbn);
                editionBook.getChildren().add(isbnEntry);
                editionBook.getChildren().add(resume);
                editionBook.getChildren().add(resumeEntry);
                editionBook.getChildren().add(createBookButton);
                editionBook.getChildren().add(returnButton);
            }
            setCenter(editionBook);
        }
    }
    /***
     * Internal Class with field to authenticate the User using this Program
     */
    public class ViewAddingPageChoiceBP extends BorderPane{
        /***
         * Constructor of BorderPane to connect the user
         */
        public ViewAddingPageChoiceBP(String isbn){

            Label numero = new Label("Numero : ");
            Spinner<Integer> spinner = new Spinner<>(0,100,0);
            Label textePage=new Label("Texte de la Page : ");
            TextField textePageEntry= new TextField("");
            Button pageAddPageButton =new Button("Ajout de la Page");{
                pageAddPageButton.setOnAction(action->{
                    int id=presenter.getIdGamebook(isbn);
                    if(id>0){
                    presenter.addPageToBook(spinner.getValue(),textePageEntry.getText(),id);

                   oPageList=(ObservableList<String>) presenter.updateOPageList(isbn,oPageList);}
                });
            }
            Button pageDeleteButton =new Button("Suppression de la Page");{
                pageDeleteButton.getStyleClass().add("delete");
                pageDeleteButton.setOnAction(action->{
                    int id=presenter.getIdGamebook(isbn);
                    if(id>0){
                        presenter.deletePage(pageEnList.getSelectionModel().getSelectedItem(),id);
                        oPageList=(ObservableList<String>) presenter.updateOPageList(isbn,oPageList);}
                });
            }
            pageAddPageButton.getStyleClass().add("add");
            Button returnButton = new Button("Retour");
            {
                returnButton.getStyleClass().add("delete");
                returnButton.setOnAction(event -> {
                    presenter.setMessage("");
                    onlyConnection(1);
                });
            }

            VBox listBox=new VBox();{
                listBox.getChildren().add(pageEnList);
                listBox.getChildren().add(returnButton);
            }
            VBox page = new VBox();{
                page.getChildren().add(numero);
                page.getChildren().add(spinner);
                page.getChildren().add(textePage);
                page.getChildren().add(textePageEntry);
                page.getChildren().add(pageAddPageButton);
                page.getChildren().add(pageDeleteButton);
            }
            setLeft(listBox);
            setCenter(page);
    }
    }



    /***
     * Internal Class with a listView and button to interact with a GameBook (Create / export)
     */
    public class ViewCreateBP extends BorderPane{
        /**
         * Constructor of BorderPane to have a view on the mainPane
         */
        public ViewCreateBP(){
            Label create = new Label("Créer un livre : "){};
            Button createBookButton = new Button("Créer");{
                createBookButton.getStyleClass().add("add");
                createBookButton.setOnAction(action->presenter.createBook());
            }


            Button editBookButton = new Button("Éditer un livre");{
                editBookButton.getStyleClass().add("edit");
                editBookButton.setOnAction(new EventHandler<ActionEvent>() {
                    @Override
                    public void handle(ActionEvent event) {
                        String choose =vueEnList.getSelectionModel().getSelectedItem();
                        if(!choose.startsWith("Publié")){
                            presenter.editingBook(choose.substring(0,13));
                            oList = (ObservableList<String>)presenter.updateOList(oList);
                        }else{
                            presenter.setMessage("Livre publié - Impossible à modifier");
                        }
                    }
                });
            }
            Button publishBookButton = new Button("Publier un livre");{
                publishBookButton.getStyleClass().add("publish");
                publishBookButton.setOnAction(new EventHandler<ActionEvent>() {
                    @Override
                    public void handle(ActionEvent event) {
                        String choose =vueEnList.getSelectionModel().getSelectedItem();
                        if(choose==null) {
                            presenter.setMessage("Vous n'avez pas sélectionnez de livre ");
                        }else if(!choose.startsWith("Publié")){
                        if(showConfirmationPublication("Voulez-vous confirmer la publication du livre ?")) {
                                if(presenter.publishBook(choose)){
                                    oList=(ObservableList<String>) presenter.updateOList(oList);
                                    presenter.setMessage("Livre publier");
                                }
                        }else{
                            presenter.setMessage("Publication annulée");
                        }
                        }else{
                            presenter.setMessage("Livre déjà publié ");
                        }
                    }
                });
            }
           /*  Button exportJSONButton = new Button("Exporter un livre");{
                exportJSONButton.setOnAction(new EventHandler<ActionEvent>() {
                    @Override
                    public void handle(ActionEvent event) {
                        MultipleSelectionModel<String> listViewModel= vueEnList.getSelectionModel();
                        String choose=listViewModel.getSelectedItem();
                        presenter.exportOne(choose);
                    }
                });
            }
         PAS DANS LES US
            Button importOneJSONButton = new Button("Importer");{
                importOneJSONButton.setOnAction(action->{
                    presenter.importOne();
                    String lastKey=presenter.getLibrary().lastKey();
                    oListe.add(presenter.getLibrary().get(lastKey).getGameBook());
                });
            }*/
            VBox hbox = new VBox(vueEnList){
            };
            VBox edit = new VBox(editBookButton,publishBookButton);
            VBox menu = new VBox();{
                menu.getChildren().add(hbox);
                menu.getChildren().add(publishLabel);
                menu.getChildren().add(create);
                menu.getChildren().add(createBookButton);
            }
            setCenter(menu);
            setRight(edit);
        }
    }

    /***
     * Internal Class with field to authenticate the User using this Program
     */
    public class ViewAuthenticationBP extends BorderPane{
        /***
         * Constructor of BorderPane to connect the user
         */
        public ViewAuthenticationBP(){
            Label nom = new Label("Nom : ");
            TextField nomEntry= new TextField("");
            Label firstname = new Label("Prenom : ");
            TextField firstnameEntry= new TextField("");
            Button connectUserButton = new Button("Connexion");{
                connectUserButton.setOnAction(action->{
                    presenter.connectionAction(nomEntry.getText(),firstnameEntry.getText());
                    oList = (ObservableList<String>)presenter.updateOList(oList);
                });
            }
            VBox connection = new VBox();{
                connection.getChildren().add(nom);
                connection.getChildren().add(nomEntry);
                connection.getChildren().add(firstname);
                connection.getChildren().add(firstnameEntry);
                connection.getChildren().add(connectUserButton);
            }
            setCenter(connection);
        }
    }


    /***
     * MainView get rooted to the MainPane
     * @return Parent of the mainPane
     */
    public Parent getRoot(){
        return mainPane;
    }

    /***
     * Setter of the presenter in the MainView
     * @param presenter Presenter to the main View
     */
    @Override
    public void setPresenter(Presenter presenter) {
        this.presenter=presenter;
    }
    @Override
    public void onlyConnection(int index){
            Node nodeOut=mainPane.getChildren().get(1);
        int length = ((StackPane) nodeOut).getChildren().size();
        for(int i=0;i<length;i++){
            ((StackPane) nodeOut).getChildren().get(i).setVisible(false);
        }
        ((StackPane)nodeOut).getChildren().get(index).setVisible(true);
    }
    @Override
    public void getMessage(String msg) {
        message.setText(msg);
    }
    @Override
    public void setUser(String msg) {
        userName.setText(msg);
    }
    @Override
    public void setFieldBorderPaneEDIT(String choose, String title, String isbn, String resume ) {
        if (centerStack.getChildren().size() == 5) {
            centerStack.getChildren().remove(4);
        }
        centerStack.getChildren().add(4,new ViewEditBookBP("Modifier les information du Livre", title, isbn, resume, choose));
    }

    public void setCurrentGamebookRead(String isbn){
        if (centerStack.getChildren().size() == 5) {
            centerStack.getChildren().remove(3);
        }
        centerStack.getChildren().add(3,new ViewAddingPageChoiceBP(isbn) );
    }


    /***
     * Clear field of a StackPane
     * @param fields All field how wants to be clear
     */
    public void clearField(TextInputControl... fields){
        for (TextInputControl field:fields) {
            field.clear();
        }
    }
    private boolean showConfirmationPublication(String message){
        Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
        alert.setTitle("Confirmer la demande");
        alert.setHeaderText(message);
        Optional<ButtonType> option = alert.showAndWait();
        if(option.get()==null){
            return false;
        }else if(option.get()==ButtonType.OK){
            return true;
        }else if(option.get()==ButtonType.CANCEL){
            return false;
        }else{
            return false;
        }
    }
}

