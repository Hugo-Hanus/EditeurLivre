package org.helmo.gbeditor.domains;

import java.util.Map;

/***
 * Class GameBook
 */
public class GameBook {

    private  String title;
    private  String isbn;
    private  String resume;
    private final Map<Integer,Page> mapPage;
    private boolean publish;

    /***
     * GameBook Constructor

     * @param title
     * @param isbn
     * @param resume
     */
    public GameBook(String title, String isbn, String resume, boolean publish, Map<Integer,Page> pageHashMap){
        this.title=title;
        this.isbn=isbn;
        this.resume=resume;
        this.publish=publish;
        this.mapPage=pageHashMap;
    }

    /***
     * Get the title of the Book
     * @return String title
     */
    public String getTitle(){
        return this.title;
    }
    /***
     *  Get Format of the book for the ListView
     * @return String formated GameBook
     */
    public String formatGameBook(boolean isPublish){
        return isPublish?"Publié "+this.isbn+" || "+this.title :this.isbn+" || "+this.title;
    }
    /***
     * Get ISBN of the book
     * @return String ISBN of Book
     */
    public String getIsbn(){
        return this.isbn;
    }
    /***
     * Get Resume of the book
     * @return String resume of Book
     */
    public String getResume(){
        return this.resume;
    }
    /**
     * Get if a book is published or not
     * @return true if he is published else false
    */
    public boolean isPublish() {
        return publish;
    }

    public Map<Integer, Page> getMapPage() {
        return this.mapPage;
    }

    public void setPublish(boolean bool){
        this.publish=bool;
    }

    /**
     * Check is the map of page is Empty
     * @return True if empty else false
     */
    public boolean isEmpty(){
        return mapPage.isEmpty();
    }

    /**
     * Check if it can add page to the map of GameBook and if the Gamebook contains this page already
     * @param page page of the Gamebook
     * @return true if it can add the page to the book else false
     */
    public boolean addPage(Page page){
        if(!mapPage.containsKey(page.getNumero())){
            mapPage.put(page.getNumero(),page);
            return true;
        }
        return false;
    }

    /**
     * Clear all pages in the mapPaga
     */
    public void clearPage(){
        mapPage.clear();
    }

    /**
     * Setter for th GameBook. Change the title,isbn,resume of it.
     * @param title title of the GameBook String
     * @param isbn ISBN of the GameBook string
     * @param resume Resume of the GameBook
     */
    public void editGameBook(String title, String isbn, String resume) {
        setTitle(title);
        setIsbn(isbn);
        setResume(resume);
    }
    public void setTitle(String title){
        this.title=title;
    }
    public void setIsbn(String isbn){
        this.isbn=isbn;
    }
    public void setResume(String resume){
        this.resume=resume;
    }
}
