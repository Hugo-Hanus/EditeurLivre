package org.helmo.gbeditor.infrastructure.dto;


/***
 * Class UserDTO using by the Mapper to avoid Object use in the Program
 */
public class UserDTO {
    public  String firstname;
    public String name;
}
