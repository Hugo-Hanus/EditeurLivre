package org.helmo.gbeditor.presenters;

import org.helmo.gbeditor.domains.GameBook;
import org.helmo.gbeditor.domains.Page;
import org.helmo.gbeditor.domains.User;

import java.util.Map;

/***
 * Interface of Presenter
 */
public interface GameBookEditing {
    /***
     * Check inputField from connection to valid data
     * @param name String name of User
     * @param firstname String name of User
     * @return TRUE if 2 inputField are not empty else FALSE
     */
    boolean checkEntryConnection(String name,String firstname);

    /***
     * Check inputField from creating Book to valid data
     * @param title String title of the book
     * @param isbn String isbn of the book
     * @param resume String resume of the book
     * @return TRUE if every input are not empty / title < 150 character && resume <500 character else FALSE
     */
    boolean checkEntryCreateBook(String title,String isbn,String resume);

    /***
     * Creating a GameBook
     * @param title String title of the book
     * @param isbn String isbn of the book
     * @param resume String resume of the book
     * @return Object GameBook
     */
    GameBook createGameBook(String title, String isbn, String resume,Map<Integer, Page> pages);
    /**
     *
     * @param firstname
     * @param name
     * @return
     */
    User createUser(String firstname, String name, Map<String,GameBook> library);

    /***
     *
     * @param text
     * @return
     */
    boolean verifyISBN(String text);
}
