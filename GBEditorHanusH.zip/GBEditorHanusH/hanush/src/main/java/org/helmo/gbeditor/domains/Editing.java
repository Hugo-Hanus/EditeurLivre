package org.helmo.gbeditor.domains;

import org.helmo.gbeditor.presenters.GameBookEditing;

import java.util.Map;

/***
 * Class Editing - Check Creation of A GameBook
 */
public class Editing implements GameBookEditing {
     private static final int  MAX_LENGTH=10;
     private static final char X_VALUE='X';
    @Override
    public boolean checkEntryConnection(String name,String firstname){
        return (!name.trim().isEmpty()) && (!firstname.trim().isEmpty());
    }
    @Override
    public boolean checkEntryCreateBook(String title,String ISBN,String resume) {
        return (!title.trim().isEmpty()) && (!ISBN.trim().isEmpty()) && (!resume.trim().isEmpty()) && (verifyLength(title, 150) && verifyLength(resume, 500));
    }
    private boolean verifyLength(String text,int length){
        return text.length()<length;
    }
    @Override
    public  User createUser(String firstname, String name, Map<String,GameBook> library){
        return new User(firstname,name,library);
    }
    @Override
    public GameBook createGameBook(String title, String isbn, String resume,Map<Integer,Page> pages) {
        return new GameBook(title,isbn,resume,false,pages);
    }

    @Override
    public boolean verifyISBN(String ISBN){
        String temp= ISBN.replace("-","");
        int length=temp.length();
        if(length==MAX_LENGTH){
            try {
            int[] isbnArray = createArrayISBNNumber(temp, length);
            return isbnArray[length - 1] == getNumberSecurity(length, isbnArray);
            }catch (NumberFormatException ex){
                return false;
            }
        }
        return false;
    }
    private static int[] createArrayISBNNumber(String temp, int length) {
        int[] isbnArray = new int[length];
        for(int i=0;i<isbnArray.length;i++){
                if((temp.charAt(i))==X_VALUE){
                    isbnArray[i]=10;
                }else{
                    isbnArray[i] = Integer.parseInt(temp.substring(i, i + 1));
                }
        }
        return isbnArray;
    }
    private static int getNumberSecurity(int length,int[] isbnArray) {
        int somme=0;
        for(int j= 0;j<isbnArray.length-1;j++){

            somme+=isbnArray[j]*(length-j);
        }
        return (11 - (somme %11))==11?0:(11 - (somme %11));
    }
}

