package org.helmo.gbeditor.infrastructure.dto;

/***
 * Class GameBookDTO using by the Mapper to avoid Object use in the Program
 */
public class GameBookDTO {
    public  String title;
    public  String isbn;
    public  String resume;
    public  UserDTO userDTO;

}
