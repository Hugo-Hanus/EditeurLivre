package org.helmo.gbeditor.storage;

import org.helmo.gbeditor.domains.Choice;
import org.helmo.gbeditor.domains.GameBook;
import org.helmo.gbeditor.domains.Page;
import org.helmo.gbeditor.domains.User;

/**
 * Interface ILibraryStorage using for operation to the DataBase
 */
public interface ILibraryStorage extends AutoCloseable{
    /**
     *Add user in DataBase
     * @param user Object User
     */
    void  addUser(User user);

    /**
     *Load all User
     */
    void loadUsers();

    /**
     *Add Gamebook to the DataBase
     * @param gamebook Object gameBook
     * @param user Object User
     */
    void addGamebook(GameBook gamebook, User user);

    /**
     * Load GameBook from user
     * @param user Object User
     */
    void loadGameBooks(User user);

    /**
     *Add Page to a GameBook using id of the GameBook
     * @param page Object page
     * @param idGameBook Int id of the gameBook
     * @return
     */
    boolean addPage(Page page,int idGameBook);

    /**
     * Load all Page of the GameBook
     * @param gamebook Object GameBook
     */
    void loadPages(GameBook gamebook);

    /**
     *Load all Choices
     */
    void loadChoice();

    /**
     *Add Choice in the DataBase
     * @param choice Object Choice
     * @return true if add else false
     */
    boolean addChoice(Choice choice);


    /**
     *Check if the user exist
     * @param user Object User
     * @return true if exist else false
     */

    boolean checkIfUserExistOrCreate(User user);

    /**
     *Check if the connection is Closed
     * @return True if it is close else false
     */

    boolean isClosed();

    /**
     * Update the GameBook information
     * @param choose Object GameBook
     * @param title String title of the new GameBook
     * @param isbn String isbn of the new GameBook
     * @param resume String resume of the new GameBook
     */

    void updateGameBookInfo(GameBook choose,String title, String isbn, String resume);
}
