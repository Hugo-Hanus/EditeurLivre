package org.helmo.gbeditor.presenters;

/***
 * Class ViewInterface
 */
public interface ViewInterface {
    /***
     * Setter of the presenter to the MainView
     * @param presenter
     */
    void setPresenter(Presenter presenter);

    /***
     * The MainView only shows a view of a StackPanel
     * @param index Int index of the StackPanel
     */
    void onlyConnection(int index);

    /***
     * Setter label message
     * @param msg String message to the label message
     */
    void getMessage(String msg);

    /***
     * Setter of the label user
     * @param user String user to the label user
     */
    void setUser(String user);

    /**
     * Set field of the editBorderaPane
     * @param choose String choose of the GameBook Selected
     * @param title String title of the GameBook Selected
     * @param isbn String isbn of the GameBook Selected
     * @param resume String resume of the GameBook Selected
     */
    void setFieldBorderPaneEDIT(String choose, String title, String isbn, String resume);

    /**
     * Set the GameBook to Add Page
     * @param idGamebook String id of the GameBook
     */
    void setCurrentGamebookRead(String idGamebook);
}
