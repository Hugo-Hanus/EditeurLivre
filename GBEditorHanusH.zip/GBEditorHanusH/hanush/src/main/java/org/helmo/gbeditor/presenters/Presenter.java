package org.helmo.gbeditor.presenters;



import org.helmo.gbeditor.domains.GameBook;
import org.helmo.gbeditor.domains.Page;
import org.helmo.gbeditor.domains.User;
import org.helmo.gbeditor.domains.exception.*;
import org.helmo.gbeditor.infrastructure.storage.dto.Choices;
import org.helmo.gbeditor.infrastructure.storage.dto.Library;
import org.helmo.gbeditor.infrastructure.storage.dto.Pages;
import org.helmo.gbeditor.infrastructure.storage.dto.Users;
import org.helmo.gbeditor.infrastructure.storage.storage.exception.*;
import org.helmo.gbeditor.repository.LibraryRepository;
import org.helmo.gbeditor.infrastructure.storage.storage.FactoryStorage;
import org.helmo.gbeditor.infrastructure.storage.storage.LibraryStorage;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.regex.Pattern;

/***
 * Class Presenter interact with GameBookEditing and MainView
 */
public class Presenter {

    private  ViewInterface view;
    private  GameBookEditing editing;
    private  LibraryRepository repository;
    private  FactoryStorage factoryStorage;
    private User user;
    private static final  String ISBN_PATTERN = "([\\d]{1}-[\\d]{6}-[\\d]{2}-[\\d|xX])";
    private final Users users=new Users();
    private final Library library=new Library();
    private final Pages pages = new Pages();
    private final Choices choices =new Choices();

    /***
     * Presenter constructor
     * @param editing  Editing connect the presenter to the domains
     * @param mainView MainView connect the presenter to the mainView
     * @param repository Repository connect the presenter to the repository
     * @param factoryStorage
     */
    public Presenter(GameBookEditing editing, ViewInterface mainView, User user, LibraryRepository repository, FactoryStorage factoryStorage) {
        this.editing = editing;
        this.view = mainView;
        this.user=user;
        this.repository = repository;
        this.factoryStorage=factoryStorage;
        int starter = 0;
        view.setPresenter(this);
        view.onlyConnection(starter);
    }

    /***
     * Presenter do the action to connect the user to the mainView
     * @param name String name of the user
     * @param firstname String firstname of the user
     */
    public void connectionAction(String name, String firstname) {
        try(LibraryStorage storage = factoryStorage.newStorage(users,library,pages,choices)) {
            if (editing.checkEntryConnection(name, firstname)) {
                user = new User(firstname,name,new HashMap<>());
                if (storage.checkIfUserExistOrCreate(user)) {
                        view.onlyConnection(1);
                        view.setUser(firstname + " " + name);
                        view.getMessage("");
                    } else {
                    view.getMessage("Erreur lors de la connexion sur le check");
                }
            }else{
                view.getMessage("Un des champs est vide");
            }
        } catch (UnableToSetupException e) {
            throw new UnableToConnectToDb(e);
        }
    }

    /***
     * Presenter do the action to create a new GameBook to the mainView
     * @param title String title of the GameBook
     * @param ISBN String isbn of the GameBook
     * @param resume String resume of the GameBook
     * @return TRUE IF it can create a new GameBook else FALSE
     */
    public boolean newBook(String title, String ISBN, String resume) {
        try(LibraryStorage storage = factoryStorage.newStorage(users,library,pages,choices)) {
        if (editing.checkEntryCreateBook(title, ISBN, resume)) {
            return gameBookAdded(title, ISBN, resume, storage);
        } else {
            view.getMessage("Un des champs est vide ! OU Votre numero de securite n'est pas correct");
            return false;
        }
        } catch (UnableToSetupException e) {
            throw new UnableToConnectToDb(e);
        }
    }

    private boolean gameBookAdded(String title, String ISBN, String resume, LibraryStorage storage) {
        GameBook newBook = editing.createGameBook(title, ISBN, resume,new HashMap<Integer, Page>());
        storage.loadGameBooks(user);
        try {
            storage.addGamebook(newBook, user);
                view.getMessage("Le livre: " + newBook.getTitle() + " a été crée");
                view.onlyConnection(1);
            return true;
        }catch (UnableToInsertInDb e){
            view.getMessage("ISBN existe déjà");
            return false;
        }
    }

    /***
     *
     * Presenter do the action to go to the creation view of a GameBook
     */
    public void createBook() {
        view.getMessage("");
        view.onlyConnection(2);
    }

    /***
     * Presenter use the repository to export a GameBook selected in the view
     * @param choose String choose of the user
     */
    public void exportOne(String choose) {
        view.getMessage("");
        if(choose!=null){
        GameBook gb=user.get(choose.substring(0,13));
        if (repository.saveGameBook(gb)) {
            view.getMessage("Le livre à été sauvegardé");
        } else {
            view.getMessage("Erreur lors de la sauvegarde");
        }
        }else{
            view.getMessage("Pas de livre sélectionné");
        }
    }

    /***
     * Presenter use the repository to import a JSON file
     */
    public void importFile() {
        view.getMessage("");
        if(repository.loadGameBook()){
            view.getMessage("Livre importé");
        }else{
            view.getMessage("Erreur lors du chargement du fichier JSON");
        }
    }

    /***
     * Presenter use GameBookEditing to verify the pattern of the ISBN (9-999999-99-9)
     * @param text String isbn of the inputField ISBN of the book
     * @return TRUE if it matches the pattern else FALSE
     */
    public boolean checkISBN(String text) {
        if (Pattern.matches(ISBN_PATTERN, text)) {
            return editing.verifyISBN(text);
        }
        return false;
    }

    /***
     * Update the Observable List with the element of the Library
     * @param oList ObservableList of the MainView
     * @return ObservableList(String) with the new ObservableList base on Library
     */
    public List<String> updateOList(List<String> oList) {
        oList.clear();
        try(LibraryStorage storage = factoryStorage.newStorage(users,library,pages,choices)) {
            storage.loadGameBooks(user);
            for (GameBook gb:user.getLibrary().values()) {
               oList.add(gb.formatGameBook(gb.isPublish())+" || "+user.formatUser());
            }
        }catch (UnableToSetupException e){
            throw new UnableToConnectToDb(e);
        }
        if(oList.isEmpty()){
            setMessage("Vous n'avez aucun livre");
        }
        Collections.sort(oList);
    return  oList;
    }

    /**
     * Update the List of Page
     * @param isbn String Isbn of the GameBook
     * @param oPageList List of the page
     * @return List of string represent Page
     */
    public List<String> updateOPageList(String  isbn,List<String> oPageList) {
        oPageList.clear();
        user.deletePagesOfGameBook(isbn);
        try(LibraryStorage storage = factoryStorage.newStorage(users,library,pages,choices)) {
            storage.loadPages(library.get( library.getGameBookIdByIsbn(isbn)));
            for (Page page: pages.getPagesMap().values()) {
                oPageList.add(page.toDetail());
            }
        }catch (UnableToSetupException e){
            throw new UnableToConnectToDb(e);
        }
        if(oPageList.isEmpty()){
            setMessage("Vous avez aucune page");
        }
        Collections.sort(oPageList);
        return  oPageList;
    }

    /**
     * Edit the gameBook
     * @param choose String choose(isbn) of the GameBook selected
     */
    public void editingBook(String choose) {
        view.getMessage("");
        view.setFieldBorderPaneEDIT(choose, user.get(choose).getTitle(),choose, user.get(choose).getResume());
        view.onlyConnection(4);
    }

    /**
     * Publish the GameBook
     *
     * @param choose String choose
     * @return true if it can publish the book else false
     */
    public boolean publishBook(String choose) {
        try {
            updatePublishGameBook(choose.substring(0,13));
            return true;
        }catch (UnableToConnectToDb e){
            view.getMessage("Erreur lors de la publication du livre");
            return false;
        }catch (UnableToPublishGameBookException ex){
            view.getMessage(ex.getMessage());
            return false;
        }
    }

    /**
     * Add page to the GameBook
     * @param numero Int number of the page
     * @param text String Text of the page
     * @param idGamebook Int id of the gameBook
     */
    public void addPageToBook(int numero,String text,int idGamebook){
    if(pages.containsNumber(numero)){
        try(LibraryStorage storage = factoryStorage.newStorage(users,library,pages,choices)) {
            storage.addExistPage(new Page(text,numero,new ArrayList<>()),idGamebook);
            view.getMessage("Page ajouté");
        }catch (UnableToInsertInDb e){
            view.getMessage("Impossible d'ajouter la page");
        }
    }else{
        try(LibraryStorage storage = factoryStorage.newStorage(users,library,pages,choices)) {
            storage.addPage(new Page(text,numero,new ArrayList<>()),idGamebook);
            view.getMessage("Page ajouté");
        }catch (UnableToInsertInDb e){
            view.getMessage("Impossible d'ajouter la page");
        }
    }
    }

    /**
     * Delete the page of the GameBook
     * @param element String Number of the page
     * @param idBook Int id of the Book
     */
    public void deletePage(String element,int idBook){
         int id= pages.getId(library.get(idBook).getMapPage().get(Integer.parseInt(element.substring(4,5))));
        try(LibraryStorage storage = factoryStorage.newStorage(users,library,pages,choices)){
            storage.deletePage(id);
            view.getMessage("Page Supprimée");
        }catch (UnableDeleteException e){
            view.getMessage("Impossible de supprimer la page");
        }
    }

    /**
     * Publish the GameBook
     * @param choose String choose
     */
    private void updatePublishGameBook(String choose) {
        try(LibraryStorage storage = factoryStorage.newStorage(users,library,pages,choices)) {
            storage.loadPages(user.get(choose));
            verificationUpdate(choose, storage);
        }catch (UnableToSetupException e){
            throw new UnableToConnectToDb(e);
        }
    }

    private void verificationUpdate(String choose, LibraryStorage storage) {
        if(user.get(choose).isPublish()){
            throw new UnableToPublishGameBookException("Gamebook déjà publie");
        }else if(user.get(choose).isEmpty()){
            throw new UnableToPublishGameBookException("Gamebook contenant aucune page");
        }else{
            storage.publishGameBook(user.get(choose));
        }
    }

    /**
     *Set message to the view
     * @param message String message
     */
    public void setMessage(String message){
        view.getMessage(message);
    }

    /**
     * Update the GameBook information
     *      @param choose Object GameBook
     *      @param title String title of the new GameBook
     *      @param isbn String isbn of the new GameBook
     *      @param resume String resume of the new GameBook
     * @return true if updated else false
     */
    public boolean updateGameBook(String choose, String title, String isbn, String resume) {
        if (editing.checkEntryCreateBook(title, isbn, resume)) {
        try(LibraryStorage storage = factoryStorage.newStorage(users,library,pages,choices)) {
            try{
            storage.updateGameBookInfo(user.get(choose),title,isbn,resume);
            return true;
            }catch (UnableToUpdateInformation e){
                setMessage(e.getMessage());
                return false;
            }
        }catch (UnableToSetupException e){
            throw new UnableToConnectToDb(e);
        }}else{

            return false;
        }

    }


    public Users getUsers() {
        return this.users;
    }

    public Library getLibrary() {
        return this.library;
    }

    public Choices getChoices() {
        return this.choices;
    }

    public Pages getPages() {
        return this.pages;
    }

    /**
     * Return the ID of the GameBook using his isbn
     * @param isbn String isbn of the GameBook
     * @return Int id of the GameBook
     */
    public int getIdGamebook(String isbn) {
        return library.getGameBookIdByIsbn(isbn);
    }
    public void setView(ViewInterface view) {
        this.view = view;
    }

    public ViewInterface getView() {
        return view;
    }

    public void setEditing(GameBookEditing editing) {
        this.editing = editing;
    }

    public GameBookEditing getEditing() {
        return editing;
    }

    public void setRepository(LibraryRepository repository) {
        this.repository = repository;
    }

    public LibraryRepository getRepository() {
        return repository;
    }

    public void setFactoryStorage(FactoryStorage factoryStorage) {
        this.factoryStorage = factoryStorage;
    }

    public FactoryStorage getFactoryStorage() {
        return factoryStorage;
    }

    public User getUser() {
        return user;
    }

    public void setUser(User user) {
        this.user = user;
    }
}
