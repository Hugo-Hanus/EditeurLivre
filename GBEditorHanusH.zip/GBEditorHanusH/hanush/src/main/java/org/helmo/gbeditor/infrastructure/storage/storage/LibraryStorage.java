package org.helmo.gbeditor.infrastructure.storage.storage;

import org.helmo.gbeditor.domains.Choice;
import org.helmo.gbeditor.domains.GameBook;
import org.helmo.gbeditor.domains.Page;
import org.helmo.gbeditor.domains.User;
import org.helmo.gbeditor.infrastructure.storage.dto.Choices;
import org.helmo.gbeditor.infrastructure.storage.dto.Library;
import org.helmo.gbeditor.infrastructure.storage.dto.Pages;
import org.helmo.gbeditor.infrastructure.storage.dto.Users;
import org.helmo.gbeditor.infrastructure.storage.storage.exception.*;
import org.helmo.gbeditor.storage.ILibraryStorage;


import java.sql.*;
import java.util.ArrayList;
import java.util.HashMap;

import static org.helmo.gbeditor.infrastructure.storage.storage.AllRequest.*;

/**
 * LibraryStorage do the request to INSERT,UPDATE,DELETE Element in the DataBase
 */
public class LibraryStorage implements AutoCloseable, ILibraryStorage {


    private  Connection connection;
    private  Users users;
    private  Library library;
    private  Pages pages;
    private  Choices choices;

    /**
     * Constructor of the LibraryStorage
     * @param con Connection using ConnectionData
     * @param users Hashmap using |ID,User|
     * @param library Hashmap using |ID,GameBook|
     * @param pages HashMap using |ID,Pages|
     * @param choices HashMap using |ID,CHOICES|
     */
    public LibraryStorage(Connection con, Users users, Library library, Pages pages, Choices choices) {
        this.connection = con;
        this.users = users;
        this.library = library;
        this.pages = pages;
        this.choices = choices;
    }


    @Override
    public void addUser(User user) {
        Transaction.from(connection)
                .commit((con) -> addingUser(user))
                .onRollback(ex -> {
                    throw new UnableToSetupException(ex);
                })
                .execute();
    }

    /**
     *Add the user in the DataBase
     * @param user Object User
     * @return Boolean true if the user is add else false
     */
    private boolean addingUser(User user) {
        if (user != null) {
            try (PreparedStatement stmt = connection.prepareStatement(getCreateRequest(AllRequest.CreateRequest.CREATEUSER), Statement.RETURN_GENERATED_KEYS)) {
                stmt.setString(1, user.getFirstname());
                stmt.setString(2, user.getName());
                stmt.executeUpdate();
                try(ResultSet generatedKey = stmt.getGeneratedKeys()){
                    if (generatedKey.next()) {
                        users.addUser(generatedKey.getInt(1), user);

                        return true;
                    }
                }

                return false;

            } catch (SQLException e) {
                throw new UnableToInsertInDb(e);
            }
        }
        return false;
    }

    @Override
    public void loadUsers() {

    }

    @Override
    public void addGamebook(GameBook gamebook, User user) {
        if (user.addGameBook(gamebook.getIsbn(), gamebook)) {
            Transaction.from(connection)
                    .commit((con) -> addingGameBook(gamebook, user))
                    .onRollback(ex -> {
                        throw new UnableToSetupException(ex);
                    })
                    .execute();
        } else {
            throw new UnableToInsertInDb("Impossible ajouter le livre dans la base de donnée");
        }
    }

    /**
     * Add GameBook in the DataBase
     * @param gamebook Object GameBook
     * @param user Object User
     * @return true if added else false
     */
    private boolean addingGameBook(GameBook gamebook, User user) {
        try (PreparedStatement stmt = connection.prepareStatement(getCreateRequest(AllRequest.CreateRequest.CREATEGAMEBOOK), Statement.RETURN_GENERATED_KEYS)) {
            stmt.setString(1, gamebook.getTitle());
            stmt.setString(2, gamebook.getIsbn());
            stmt.setString(3, gamebook.getResume());
            stmt.setBoolean(4, gamebook.isPublish());
            stmt.setInt(5, users.getId(user));
            stmt.executeUpdate();
           try( ResultSet generatedKey = stmt.getGeneratedKeys()){
                if (generatedKey.next()) {
                    library.addGamebook(generatedKey.getInt(1), gamebook);
                    return true;
                }
           }
            return false;
        } catch (SQLException e) {
            throw new UnableToInsertInDb(e);
        }
    }


    @Override
    public void loadGameBooks(User user) {
        user.getLibrary().clear();
        library.clear();
        try (PreparedStatement stmt = connection.prepareStatement(getSelectRequest(AllRequest.SelectRequest.SELECTALLGAMEBOOKUSER))) {
            stmt.setInt(1, users.getId(user));
            try (ResultSet resultSet = stmt.executeQuery()) {
                while (resultSet.next()) {
                    GameBook gamebook = new GameBook(resultSet.getString(1), resultSet.getString(2), resultSet.getString(3), resultSet.getBoolean(4), new HashMap<>());
                    if (user.addGameBook(resultSet.getString(2), gamebook)) {
                        library.addGamebook(resultSet.getInt(5), gamebook);
                    }
                }
            }
        } catch (SQLException e) {
            throw new UnableToSelectInDb(e);
        }
    }

    @Override
    public boolean addPage(Page page,int gameBook) {
        if (page != null) {
            try (PreparedStatement stmt = connection.prepareStatement(getCreateRequest(AllRequest.CreateRequest.CREATEPAGE), Statement.RETURN_GENERATED_KEYS)) {
                stmt.setString(1, page.getTextPage());
                stmt.setInt(2, page.getNumero());
                stmt.setInt(3, gameBook);//idgamebook
                stmt.executeUpdate();
                try(ResultSet generatedKey = stmt.getGeneratedKeys()){
                if (generatedKey.next()) {
                    pages.addPages(generatedKey.getInt(1), page);
                    return true;
                }}
                return false;
            } catch (SQLException e) {
                throw new UnableToInsertInDb(e);
            }
        }
        return false;
    }

    @Override
    public void loadPages(GameBook gamebook) {
        pages.clear();
        try (PreparedStatement stmt = connection.prepareStatement(getSelectRequest(AllRequest.SelectRequest.SELECTPAGES))) {
            stmt.setInt(1, library.getId(gamebook));
            try (ResultSet resultSet = stmt.executeQuery()) {
                while (resultSet.next()) {
                    Page page = new Page(resultSet.getString(2), resultSet.getInt(3), new ArrayList<>());
                    if(gamebook.addPage(page)){
                        pages.addPages(resultSet.getInt(1), page);
                    }
                }
            }
        } catch (SQLException e) {
            throw new UnableToSelectInDb(e);
        }
    }

    @Override
    public void loadChoice() {

    }

    @Override
    public boolean addChoice(Choice choice) {
        if (choice != null) {
            try (PreparedStatement stmt = connection.prepareStatement(getCreateRequest(AllRequest.CreateRequest.CREATECHOICE), Statement.RETURN_GENERATED_KEYS)) {
                stmt.setInt(1, choice.getFromPage());
                stmt.setString(2, choice.getText());
                stmt.setInt(3, choice.getToPage());
                stmt.executeUpdate();
               try( ResultSet generatedKey = stmt.getGeneratedKeys()){
                if (generatedKey.next()) {
                    choices.addChoice(generatedKey.getInt(1), choice);
                    return true;
                }}
                return false;
            } catch (SQLException e) {
                throw new UnableToInsertInDb(e);
            }
        }
        return false;
    }


    @Override
    public boolean checkIfUserExistOrCreate(User user) {
        try (PreparedStatement stmt = connection.prepareStatement(getSelectRequest(AllRequest.SelectRequest.SELECTUSER))) {
            stmt.setString(1, user.getFirstname());
            stmt.setString(2, user.getName());
            try (ResultSet resultSet = stmt.executeQuery()) {
                if (resultSet.next()) {
                    users.addUser(resultSet.getInt(1), user);
                } else {
                    addUser(user);
                }
                return true;
            } catch (UnableToSetupException ex) {
                throw new UnableToSetupException(ex);
            }
        } catch (SQLException e) {
            throw new UnableToSelectInDb(e);
        }

    }

    @Override
    public boolean isClosed() {
        try {
            return connection.isClosed();
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }

    @Override
    public void updateGameBookInfo(GameBook choose, String title, String isbn, String resume) {
        try (PreparedStatement stmt = connection.prepareStatement(getUpdateRequest(AllRequest.UpdateRequest.UPDATEGAMEBOOK))) {
            stmt.setString(1, title);
            stmt.setString(2, isbn);
            stmt.setString(3, resume);
            stmt.setString(4, choose.getIsbn());
            if (stmt.execute()) {
                choose.editGameBook(title, isbn, resume);
            }
        } catch (SQLException ex) {
            throw new UnableToUpdateInformation(ex);
        }
    }

    /**
     * Publish GameBook int the DataBase
     * @param gb Object GameBook
     */
    public void publishGameBook(GameBook gb) {
        int id = library.getId(gb);
        try (PreparedStatement stmt = connection.prepareStatement(getUpdateRequest(AllRequest.UpdateRequest.UPDATEGAMEBOOKPUBLISH))) {
            stmt.setInt(1, id);
            if (stmt.execute()) {
                gb.setPublish(true);
                library.get(id).setPublish(true);
            }
        } catch (SQLException e) {
            throw new UnableToSelectInDb(e);
        }
    }

    @Override
    public void close() {
        try {
            connection.close();
        } catch (SQLException ex) {
            throw new DeconnectionFailedException(ex);
        }
    }

    /**
     * Add Page if the number already Exist
     * @param page Objetc Page
     * @param gamebook Int id of the gameBook
     */
    public void addExistPage(Page page,int gamebook) {
        int generated = 0;
        try (PreparedStatement stmt = connection.prepareStatement(getCreateRequest(CreateRequest.CREATEPAGE), Statement.RETURN_GENERATED_KEYS)) {
            stmt.setString(1, page.getTextPage());
            stmt.setInt(2, page.getNumero());
            stmt.setInt(3,gamebook);
            stmt.executeUpdate();
            try(ResultSet generatedKey = stmt.getGeneratedKeys()){
            if (generatedKey.next()) {
                generated=generatedKey.getInt(1);
            }}
        } catch (SQLException e) {
            throw new UnableToInsertInDb(e);
        }
        upadteOtherPage(page, gamebook, generated);
    }

    private void upadteOtherPage(Page page, int gamebook, int generated) {
        try (PreparedStatement stmt = connection.prepareStatement(getUpdateRequest(UpdateRequest.UPDATEPAGE), Statement.RETURN_GENERATED_KEYS)) {
            stmt.setInt(1, page.getNumero());
            stmt.setInt(2, gamebook);
            stmt.setInt(3, generated);
            stmt.executeUpdate();
        } catch (SQLException e) {
            throw new UnableToInsertInDb(e);
        }
    }

    /**
     * Delete a Page using id of the page
     * @param idPage Int number of the page
     */
    public void deletePage(int idPage){
        try (PreparedStatement stmt = connection.prepareStatement(getDeleteRequest(DeleteRequest.DELETECHOICEPAGE))) {
            stmt.setInt(1, idPage);
            stmt.setInt(2, idPage);
            stmt.executeUpdate();
        } catch (SQLException e) {
            throw new UnableDeleteException(e);
        }
        try (PreparedStatement stmt = connection.prepareStatement(getDeleteRequest(DeleteRequest.DELETEPAGE))) {
            stmt.setInt(1, idPage);
            stmt.executeUpdate();
        } catch (SQLException e) {
            throw new UnableDeleteException(e);
        }

    }
    public void setConnection(Connection connection) {
        this.connection = connection;
    }

    public Connection getConnection() {
        return connection;
    }

    public void setUsers(Users users) {
        this.users = users;
    }

    public Users getUsers() {
        return users;
    }

    public void setLibrary(Library library) {
        this.library = library;
    }

    public Library getLibrary() {
        return library;
    }

    public void setPages(Pages pages) {
        this.pages = pages;
    }

    public Pages getPages() {
        return pages;
    }

    public void setChoices(Choices choices) {
        this.choices = choices;
    }

    public Choices getChoices() {
        return choices;
    }

}
