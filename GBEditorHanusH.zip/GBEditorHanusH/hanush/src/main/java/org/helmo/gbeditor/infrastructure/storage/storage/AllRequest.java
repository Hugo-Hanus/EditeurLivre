package org.helmo.gbeditor.infrastructure.storage.storage;

/**
 * Class Using an Enum with All Request used in this program
 */
public class AllRequest {

    /**
     *Enum of All Create Request
     */
    enum CreateRequest {
        CREATEUSER,
        CREATEGAMEBOOK,
        CREATEPAGE,
        CREATECHOICE
    }

    /**
     *Enum of All Update Request
     */
    enum UpdateRequest{
        UPDATEGAMEBOOKPUBLISH,
        UPDATEPAGE,
        UPDATEGAMEBOOK,
        UPDATECHOICE,
    }

    /**
     *Enum of All Delete Request
     */
    enum DeleteRequest{
        DELETEGAMEBOOK,
        DELETEPAGE,DELETECHOICEPAGE,
        DELETECHOICE
    }

    /**
     * Enume of All Select request
     */
    enum SelectRequest{
        SELECTUSER,
        SELECTALLGAMEBOOKUSER,
        SELECTPAGES,
        SELECTCHOICES,
        SELECTALLGAMEBOOKINFORMATIONOFUSER
    }


    /**
     * Get the Create Request using an element of the CreateRequest Enum
     * @param createRequest Element of the CreateRequest Enum
     * @return String SQL Request (Insert)
     */
    public static String getCreateRequest(CreateRequest createRequest) {
        switch (createRequest) {
            case CREATEUSER:
                return "INSERT INTO utilisateur(firstname,lastname) VALUES (?,?)";
            case CREATEGAMEBOOK:
                return "INSERT INTO gamebook(title,isbn,resume,is_publish,id_user) VALUES (?,?,?,?,?)";
            case CREATEPAGE:
                return "INSERT INTO page(text,numero,id_gamebook) VALUES (?,?,?)";

            case CREATECHOICE:
                return "INSERT INTO choix(id_page,text,id_page_1) VALUES (?,?,?)"; default:
                return "";
        }
    }

    /**
     *Get the Update Request using an element of the UpdateRequest Enum
     * @param updateRequest Element of the UpdateRequest Enum
     * @return String SQL Request (UPDATE)
     */
    public static String getUpdateRequest(UpdateRequest updateRequest){
        switch (updateRequest){
        case UPDATEGAMEBOOK:
        return "UPDATE gamebook SET title=?,isbn=?,resume=? WHERE isbn=? ";
        case UPDATEGAMEBOOKPUBLISH:
        return "UPDATE gamebook SET is_publish = 1 WHERE id_gamebook=?";
        case UPDATEPAGE:
        return " UPDATE page SET numero = numero + 1 WHERE numero >= ? AND (id_gamebook = ? AND id_page <> ?);";
        case UPDATECHOICE:
        return "UPCHOICE";
        default:return "";
        }
    }

    /**
     *Get the Delete Request using an element of the DeleteRequest enum
     * @param deleteRequest Element of the DeleteRequest Enum
     * @return String SQL Request (DELETE)
     */
    public static String getDeleteRequest(DeleteRequest deleteRequest){
        switch (deleteRequest){
            case DELETEGAMEBOOK:
                return "GAMEBOOK";
            case DELETEPAGE:
                return "DELETE p FROM page p WHERE p.id_page = ? ;";
            case DELETECHOICEPAGE:
                return "DELETE c FROM choix c WHERE c.id_page = ? OR c.id_page_1 = ?;";
            case DELETECHOICE:
                return "CHOICE";
            default:return "";
        }
    }

    /**
     *Get the Select Request using an element of the SelectRequest
     * @param selectRequest Element of the SelectRequest Enum
     * @return String SQL Request (SELECT)
     */
    public static String getSelectRequest(SelectRequest selectRequest){
        switch (selectRequest){
            case SELECTUSER:
                return "SELECT id_user,firstname,lastname FROM utilisateur WHERE firstname=? AND lastname=?;";
            case SELECTALLGAMEBOOKUSER:
                return "SELECT title,isbn,resume,is_publish,id_gamebook FROM gamebook WHERE id_user=?";
            case SELECTPAGES:
                return "SELECT id_page,text,numero FROM page WHERE id_gamebook=?";
            case SELECTCHOICES:
                return "SELECT id_page,id_pages_1 FROM choix WHERE id_page=?";
            case SELECTALLGAMEBOOKINFORMATIONOFUSER:
                return "SELECT g.isbn,SUBSTRING(g.title,1,15),CONCAT(u.firstname,'.',u.lastname) FROM gamebook g JOIN utilisateur u ON g.id_user=u.id_user WHERE  g.is_publish=0 AND u.id_user=?";
            default:return "";
        }
    }

}
