module org.helmo {
    requires javafx.controls;
    requires java.desktop;
    requires javafx.graphics;
    requires java.sql;
    requires com.google.gson;
    exports org.helmo.gbeditor;
}